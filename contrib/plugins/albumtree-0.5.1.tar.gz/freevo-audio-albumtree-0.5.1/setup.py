#!/usr/bin/env python

"""Setup script for the freevo mail plugin."""

__revision__ = "$Id $"

from distutils.core import setup, Extension
import distutils.command.install
import freevo.util.distutils

# disclaimer
disclaimer = """
***************** [Setup ended] ********************
****************************************************

"""

fp = file('./README')
disclaimer += "".join(fp.readlines())
fp.close()

# now start the python magic
setup (name = "freevo-audio-albumtree",
       version = '0.5.1',
       description = "audio tree",
       author = "M Voncken",
       author_email = "mvoncken@gmail.com",
       url = "http://freevo.sourceforge.net/cgi-bin/doc/PluginAudioAlbumTree",
       package_dir = freevo.util.distutils.package_dir,
       packages = freevo.util.distutils.packages,
       data_files = freevo.util.distutils.data_files
      )
print disclaimer

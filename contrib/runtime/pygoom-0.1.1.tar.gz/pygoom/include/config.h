/******************************************************************************
 * This file is part of MPlayer Audio Visualization.                          *
 *                                                                            *
 *                                                                            *
 *  MPlayer Audio Visualization is free software; you can redistribute it     *
 *  and/or modify it under the terms of the GNU General Public License as     *
 *  published by the Free Software Foundation; either version 2 of the        *
 *  License, or (at your option) any later version.                           *
 *                                                                            *
 *  MPlayer Audio Visualization is distributed in the hope that it will be    *
 *  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General *
 *  Public License for more details.                                          *
 *                                                                            * 
 *  You should have received a copy of the GNU General Public License         *
 *  along with MPlayer Audio Visualization; if not, write to the Free         *
 *  Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA         *
 *  02111-1307  USA                                                           *
 ******************************************************************************/
#ifndef _H_CONFIG_
#define _H_CONFIG_

#define SHARED_FILE ".mplayer/mplayer-af_export"

#ifndef DEBUG
#define DEBUG 0
#endif
#define ARCH_X86 1
#define USE_MMX 1
#ifndef MMX
#define MMX 1
#endif
#define HAVE_MMX2 1
#define HAVE_MMX1 1
#define HAVE_SSE2 1
#define HAVE_SSE 1

#define MAX_FRAMERATE 25
#define INTERVAL (1000000/MAX_FRAMERATE)  /**< interval in seconds */

#define DEF_FS     0   /* Default Full Screen Mode */
#endif // _H_CONFIG_

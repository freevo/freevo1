pygoom
======

  This is a python wrapper to call C functions of GOOM, an audio
visualization library.

  You can get more info about this package using distutils functions
in ./setup.py, for example:
   
	./setup.py --contact 

will return the maintainer's or author's name, while:
 
	./setup.py --url

will return the package url.
   
   For more info use:

        ./setup.py --help       


INSTALL
=======

   Check INSTALL.txt


LICENSE
=======
   GNU GPL >= 2.0
